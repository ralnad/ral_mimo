import argparse
import json
import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"


def load_json(filename: str):
    path = DATA_DIR / filename
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def tokenize(text: str) -> List[str]:
    normalized = re.sub(r"[^\w\u4e00-\u9fff]+", " ", text.lower())
    return [token for token in normalized.split() if token]


def overlap_score(query_tokens: List[str], doc_tokens: List[str]) -> float:
    if not query_tokens or not doc_tokens:
        return 0.0
    query_set = set(query_tokens)
    doc_set = set(doc_tokens)
    common = query_set & doc_set
    if not common:
        return 0.0
    return len(common) / math.sqrt(len(query_set) * len(doc_set))


@dataclass
class AgentContext:
    user_message: str
    intent: str = "general_question"
    urgency: str = "medium"
    kb_hits: List[Dict] = field(default_factory=list)
    ticket_hits: List[Dict] = field(default_factory=list)
    rule_result: Dict = field(default_factory=dict)
    draft_reply: str = ""
    final_reply: str = ""
    trace: List[str] = field(default_factory=list)

    def log(self, message: str) -> None:
        self.trace.append(message)


class IntentAgent:
    def classify(self, ctx: AgentContext) -> None:
        text = ctx.user_message.lower()
        if any(word in text for word in ["退款", "退货", "refund", "取消订单"]):
            ctx.intent = "refund_request"
        elif any(word in text for word in ["物流", "快递", "发货", "没收到", "配送", "shipment"]):
            ctx.intent = "shipping_issue"
        elif any(word in text for word in ["开票", "发票", "invoice"]):
            ctx.intent = "invoice_request"
        elif any(word in text for word in ["登录", "验证码", "密码", "账号", "account", "login"]):
            ctx.intent = "account_issue"
        elif any(
            word in text
            for word in ["坏了", "故障", "无法使用", "bug", "报错", "发热", "异常", "安全问题", "漏电"]
        ):
            ctx.intent = "product_issue"
        else:
            ctx.intent = "general_question"

        if any(word in text for word in ["马上", "尽快", "投诉", "生气", "urgent", "asap"]):
            ctx.urgency = "high"
        elif any(word in text for word in ["有空", "咨询", "了解一下"]):
            ctx.urgency = "low"
        else:
            ctx.urgency = "medium"
        ctx.log(f"IntentAgent: intent={ctx.intent}, urgency={ctx.urgency}")


class KnowledgeRetrievalAgent:
    def __init__(self, knowledge_base: List[Dict]):
        self.knowledge_base = knowledge_base

    def retrieve(self, ctx: AgentContext, top_k: int = 3) -> None:
        query_tokens = tokenize(ctx.user_message + " " + ctx.intent)
        scored = []
        for item in self.knowledge_base:
            doc_text = " ".join(
                [
                    item.get("title", ""),
                    item.get("content", ""),
                    " ".join(item.get("tags", [])),
                ]
            )
            score = overlap_score(query_tokens, tokenize(doc_text))
            if ctx.intent in item.get("tags", []):
                score += 0.5
            if score > 0:
                scored.append((score, item))
        scored.sort(key=lambda x: x[0], reverse=True)
        ctx.kb_hits = [item for _, item in scored[:top_k]]
        ctx.log(f"KnowledgeRetrievalAgent: matched={len(ctx.kb_hits)}")


class TicketRetrievalAgent:
    def __init__(self, historical_tickets: List[Dict]):
        self.historical_tickets = historical_tickets

    def retrieve(self, ctx: AgentContext, top_k: int = 2) -> None:
        query_tokens = tokenize(ctx.user_message + " " + ctx.intent)
        scored = []
        for item in self.historical_tickets:
            doc_text = f"{item.get('customer_issue', '')} {item.get('resolution', '')}"
            score = overlap_score(query_tokens, tokenize(doc_text))
            if item.get("intent") == ctx.intent:
                score += 0.4
            if score > 0:
                scored.append((score, item))
        scored.sort(key=lambda x: x[0], reverse=True)
        ctx.ticket_hits = [item for _, item in scored[:top_k]]
        ctx.log(f"TicketRetrievalAgent: matched={len(ctx.ticket_hits)}")


class RuleEngineAgent:
    def evaluate(self, ctx: AgentContext) -> None:
        text = ctx.user_message.lower()
        escalate = False
        reason = ""

        if any(word in text for word in ["投诉", "律师", "12315", "曝光"]):
            escalate = True
            reason = "用户存在强烈投诉或法律风险表达"
        elif ctx.intent == "refund_request" and any(word in text for word in ["超过", "用了很久", "拆封"]):
            escalate = True
            reason = "退款请求可能超出标准规则，需要人工复核"
        elif ctx.intent == "product_issue" and any(
            word in text for word in ["安全", "漏电", "爆炸", "发热", "烫手", "隐患"]
        ):
            escalate = True
            reason = "产品问题涉及安全风险"

        ctx.rule_result = {
            "escalate": escalate,
            "reason": reason,
            "priority": "P1" if ctx.urgency == "high" or escalate else "P2",
        }
        ctx.log(
            "RuleEngineAgent: "
            f"escalate={ctx.rule_result['escalate']}, priority={ctx.rule_result['priority']}"
        )


class ResponseAgent:
    def compose(self, ctx: AgentContext) -> None:
        greeting = "您好，感谢您的反馈。"

        if ctx.rule_result.get("escalate"):
            body = (
                f"您反馈的问题我们已经重点记录，因 {ctx.rule_result['reason']}，"
                "该问题将优先转交人工专员跟进。"
            )
            follow_up = "为了加快处理，麻烦您补充订单号、联系方式以及相关截图。"
        else:
            snippets = []
            if ctx.kb_hits:
                snippets.append(f"根据知识库，{ctx.kb_hits[0]['content']}")
            if ctx.ticket_hits:
                snippets.append(f"参考相似工单，通常可按以下方式处理：{ctx.ticket_hits[0]['resolution']}")
            if not snippets:
                snippets.append("目前我们建议先核对订单信息、账号状态或操作步骤，以便进一步定位问题。")
            body = " ".join(snippets)
            follow_up = "如果您愿意，我也可以继续帮您整理下一步处理建议。"

        closing = "感谢您的耐心，我们会尽快协助您解决。"
        ctx.draft_reply = f"{greeting}{body}{follow_up}{closing}"
        ctx.log("ResponseAgent: draft reply generated")


class QualityAgent:
    def review(self, ctx: AgentContext) -> None:
        reply = ctx.draft_reply
        if len(reply) < 40:
            reply += " 为了更准确处理，请尽量提供更完整的信息。"
        if "您好" not in reply:
            reply = "您好，" + reply
        if ctx.rule_result.get("escalate") and "人工专员" not in reply:
            reply += " 该问题已进入人工升级流程。"
        ctx.final_reply = reply
        ctx.log("QualityAgent: reply reviewed and finalized")


class SupportOrchestrator:
    def __init__(self):
        self.intent_agent = IntentAgent()
        self.kb_agent = KnowledgeRetrievalAgent(load_json("knowledge_base.json"))
        self.ticket_agent = TicketRetrievalAgent(load_json("historical_tickets.json"))
        self.rule_engine = RuleEngineAgent()
        self.response_agent = ResponseAgent()
        self.quality_agent = QualityAgent()

    def run(self, user_message: str) -> AgentContext:
        ctx = AgentContext(user_message=user_message)
        self.intent_agent.classify(ctx)
        self.kb_agent.retrieve(ctx)
        self.ticket_agent.retrieve(ctx)
        self.rule_engine.evaluate(ctx)
        self.response_agent.compose(ctx)
        self.quality_agent.review(ctx)
        return ctx


def pretty_print(ctx: AgentContext) -> None:
    print("=" * 72)
    print("客户问题:")
    print(ctx.user_message)
    print("=" * 72)
    print(f"识别意图: {ctx.intent}")
    print(f"紧急程度: {ctx.urgency}")
    print(f"规则判断: {json.dumps(ctx.rule_result, ensure_ascii=False)}")
    print("-" * 72)
    print("知识库命中:")
    if ctx.kb_hits:
        for item in ctx.kb_hits:
            print(f"- [{item['id']}] {item['title']}")
    else:
        print("- 无")
    print("-" * 72)
    print("历史工单命中:")
    if ctx.ticket_hits:
        for item in ctx.ticket_hits:
            print(f"- [{item['id']}] {item['customer_issue']}")
    else:
        print("- 无")
    print("-" * 72)
    print("生成回复:")
    print(ctx.final_reply)
    print("-" * 72)
    print("执行轨迹:")
    for step in ctx.trace:
        print(f"- {step}")
    print("=" * 72)


def main():
    parser = argparse.ArgumentParser(description="Customer Support Multi-Agent Demo")
    parser.add_argument(
        "--message",
        type=str,
        default="我的订单已经超过7天还没收到，物流信息也一直没更新，麻烦尽快处理。",
        help="User message to process",
    )
    args = parser.parse_args()

    orchestrator = SupportOrchestrator()
    ctx = orchestrator.run(args.message)
    pretty_print(ctx)


if __name__ == "__main__":
    main()
